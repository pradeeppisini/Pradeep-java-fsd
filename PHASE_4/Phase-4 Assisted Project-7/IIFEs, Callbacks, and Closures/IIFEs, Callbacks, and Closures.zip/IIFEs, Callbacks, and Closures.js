//IIFEs, Callbacks, and Closures

const EmpId=(function(){
    let count=0;
    return function(){
        ++count;
        return 'Emp${count}';
    };
})();

console.log("New Employee IDs are listed here");
console.log("Pradeep:"+EmpId());
console.log("Sweety:"+EmpId());
console.log("Brundha"+EmpId());

//Callbacks

console.log("\n");

//To start the output from the next line

function fullName(firstName,lastName, callback){
    console.log("My Name is" + firstName +""+lastName);
    callback(lastName);
}
var greeting=function(ln){
    console.log("Welcome"+ ln);
};
fullName("Pradeep","Rocky",greeting);
console.log("\n");
fullName("Akash","Sandy",greeting);
console.log("\n");
fullName("Dheeraj","Bhavana",greeting);
