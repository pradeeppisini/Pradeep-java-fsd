package LinearSearch;


public class LinearSearchDemo {
    // This function returns index of element x in arr[]
    static int search(int arr[], int n, int x) {
        for (int i = 0; i < n; i++) {
            // Return the index if the element is found
            if (arr[i] == x)
                return i;
        }
        // Return -1 if the element is not found
        return -1;
    }

    public static void main(String args[]) {
        int arr[] = { 2, 3, 4, 10, 40,78,54,67,32};
        int x = 54;
        int n = arr.length;

        // Function call
        int result = search(arr, n, x);
        if (result == -1)
            System.out.print("Element is not present in array");
        else
            System.out.print("Element is present at index " + result);
    }
}
