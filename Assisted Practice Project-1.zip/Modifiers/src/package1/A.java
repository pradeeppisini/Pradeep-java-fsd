package package1;

public class A {
	public int x1;		//public
	int x2;        		//Default
	protected int x3=55;//protected
	private int x4;		//private
	
	public void mA()
	{
		x1=10;
	}

}
