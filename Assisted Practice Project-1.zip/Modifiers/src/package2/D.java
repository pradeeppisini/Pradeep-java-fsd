package package2;

import package1.A;
public class D {
	public void mB()
	{
		A a = new A();
		a.x1 = 23;
		
		//default class cannot be 
		//accessed in other package classes
		//a.x2 = 55;
		
		
	}
}
