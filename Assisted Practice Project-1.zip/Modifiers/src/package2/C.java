package package2;

import package1.A;
public class C extends A{
	
	public void mB() {
		A a = new A();
		
		a.x1=23;
		
		//as Default class cannot be accessed in 
		//other classes
		//a.x2=55;
		
		
		this.x3=55;
		
		// private class cannot be accessed 
		//in other class
		//a.x4=55;
	}

}
