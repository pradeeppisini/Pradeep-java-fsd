/**
 * 
 */
/**
 * 
 */
module ArthimaticCalculator {
}