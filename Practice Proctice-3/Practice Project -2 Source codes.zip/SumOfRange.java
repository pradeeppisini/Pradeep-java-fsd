package RangeQueries;

public class SumOfRange {
	static int sumRange(int arr[], int L, int R) {
		int sum=0;
		for(int i=L;i<=R;i++)
			sum = sum+arr[i];
		return sum;
	}
	
	public static void main(String args[])
	{
		int arr[] = {23,54,67,8,9,1,89,89,27,78,34};
		int L=5;
		int R=8;
		System.out.println("Sum of elements from index " + L + " to " +R + " is " + sumRange(arr,L,R));
	}
}
