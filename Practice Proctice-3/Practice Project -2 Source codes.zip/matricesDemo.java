package matrices;

public class matricesDemo {
	public static void main(String[] args) {
		// Initialize the first matrix
		double[][] matA = { {3, -2, 5}, {3, 0, 4} };
	        
	     // Initialize the second matrix
	    double[][] matB = { {2, 3}, {-9, 0}, {0, 4} };
	        
	    // Create a new matrix for storing the result
	    double[][] resMat = new double[matA.length][matB[0].length];
	        // Perform matrix multiplication
	    for (int i = 0; i < matA.length; i++) {
	    	for (int j = 0; j < matB[0].length; j++) {
	                for (int k = 0; k < matB.length; k++) {
	                	resMat[i][j] += matA[i][k] * matB[k][j];
	                }
	            }
	        }
	        
	        // Print the resultant matrix
	        System.out.println("Resultant Matrix:");
	        for (double[] row : resMat) {
	            for (double val : row) {
	                System.out.print(val + "\t");
	            }
	            System.out.println();
	        }
	    }
	}
