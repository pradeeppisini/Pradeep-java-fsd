package OrderStatistics;
import java.util.PriorityQueue;

public class OrderStatisticsDemo {


	    public static void main(String[] args) {
	        int[] arr = {59,23,56,78,89,34,67,78,89};
	        int k = 4;
	        System.out.println("Fourth smallest element: " + kthSmallest(arr, k));
	    }

	    public static int kthSmallest(int[] arr, int k) {
	        PriorityQueue<Integer> pq = new PriorityQueue<>();
	        for (int i = 0; i < arr.length; i++) {
	            pq.add(arr[i]);
	        }
	        int kthSmallest = -1;
	        while (k-- > 0) {
	            kthSmallest = pq.poll();
	        }
	        return kthSmallest;
	    }
	}

