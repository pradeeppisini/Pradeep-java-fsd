package Stack;

import java.util.Stack;

public class StackDemo {
    public static void main(String[] args) {
        Stack<Integer> myStack = new Stack<>();
        
        // Adding some elements to the stack
        myStack.push(1);
        myStack.push(2);
        myStack.push(3);
        myStack.push(4);
        myStack.push(5);
        
        
        // Popping elements from the stack
        while (!myStack.isEmpty()) {
            System.out.print(myStack.pop() + " ");
        }
    }
}