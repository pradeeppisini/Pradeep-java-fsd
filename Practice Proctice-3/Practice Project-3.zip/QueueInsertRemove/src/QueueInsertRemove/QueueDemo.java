
package QueueInsertRemove;

import java.util.*;
public class QueueDemo {
    public static void main(String[] args) {
        // Create and initialize a Queue using a LinkedList
        Queue<String> queue = new LinkedList<>();

        // Adding new elements to the Queue (The Enqueue operation)
        queue.add("Element 1");
        queue.add("Element 2");
        queue.add("Element 3");
        queue.add("Element 4");
        queue.add("Element 5");
        queue.add("Element 6");
        queue.add("Element 7");

        System.out.println("Queue: " + queue);

        // Removing an element from the Queue using remove() 
        String removedElement = queue.remove();
        System.out.println("Removed Element: " + removedElement);

        System.out.println("Queue after remove operation: " + queue);
    }
}
