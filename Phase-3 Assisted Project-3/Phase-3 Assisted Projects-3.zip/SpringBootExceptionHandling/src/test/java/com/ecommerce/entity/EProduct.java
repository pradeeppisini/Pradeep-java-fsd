package com.ecommerce.entity;

public class EProduct {

}
