package com.b;
public class Books {
	
	private int book_id;
	private String title;
	private String author_fname;
	private String author_lname;
	private int released_year;
	private int stock_quantity;
	private int pages;
	
	
	public int getBook_id() {
		return book_id;
	}
	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor_fname() {
		return author_fname;
	}
	public void setAuthor_fname(String author_fname) {
		this.author_fname = author_fname;
	}
	public String getAuthor_lname() {
		return author_lname;
	}
	public void setAuthor_lname(String author_lname) {
		this.author_lname = author_lname;
	}
	public int getReleased_year() {
		return released_year;
	}
	public void setReleased_year(int released_year) {
		this.released_year = released_year;
	}
	public int getStock_quantity() {
		return stock_quantity;
	}
	public void setStock_quantity(int stock_quantity) {
		this.stock_quantity = stock_quantity;
	}
	public int getPages() {
		return pages;
	}
	public void setPages(int pages) {
		this.pages = pages;
	}	
}
