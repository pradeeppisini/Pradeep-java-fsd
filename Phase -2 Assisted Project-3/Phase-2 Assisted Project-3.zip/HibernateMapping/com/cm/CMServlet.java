package com.cm;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class CMServlet extends HttpServlet {
	
	SessionFactory sessionFactory;
	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
		
		sessionFactory = HibernateUtil.getSessionFactory();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		try {
			Session session = sessionFactory.openSession();
			
			
			List<Product> products = session.createQuery("from Product").list();
			
			out.println("<h4> Component Mapping </h4><br>");
			
			for(Product p : products) {
				out.println("ID : " + p.getID() + "NAME : " +p.getName() + "PRICE : "+p.getPrice() + "DATE ADDED : "+p.getDateAdded());
				ProductParts parts = p.getParts();
				out.println("PARTS : " + parts.getCpu() + ",   " + parts.getHdd() + ",  "+parts.getRam());
				
				out.println("<hr>");			
			
			}
			
			session.close();
		
		}catch (Exception e) {
            out.println(e.getMessage());
    }

	
	}

}
