package SleepWait;
public class SleepWaitDemo {
    public static void main(String[] args) {
        // Create new MyThread instance
        MyThread t = new MyThread();
        
        // Start the new thread
        t.start();
        
        //  thread wait for 3 seconds 
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        // Notify the waiting thread
        synchronized(t) {
            t.notify();
        }
    }
}

class MyThread extends Thread {
    @Override
    public void run() {
        String name = Thread.currentThread().getName();
        System.out.println(name + ": Going to sleep...");
        try {
            Thread.sleep(2000); // Sleep for 2 seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(name + ": Woke up after 2 seconds.");

        System.out.println(name + ": Going to wait...");
        synchronized(this) {
            try {
                this.wait(); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println(name + ": Was woken up!");
    }
}