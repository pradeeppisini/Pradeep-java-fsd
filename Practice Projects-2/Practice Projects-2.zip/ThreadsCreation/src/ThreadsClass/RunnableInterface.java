package ThreadsClass;

class MyRunnable implements Runnable {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println(Thread.currentThread().getId() + " - Count: " + i);
        }
    }
}

public class RunnableInterface{
    public static void main(String[] args) {
        MyRunnable myRunnable = new MyRunnable();

        // threads using the Runnable object
        Thread thread1 = new Thread(myRunnable);
        Thread thread2 = new Thread(myRunnable);

        // Start the threads
        thread1.start();
        thread2.start();
    }
}
