
//objective of the program is to write data into a file

package SleepWait;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriteDemo {
	public static void main(String args[])
	{
		String data = "101. P Pradeep,Vizag, Andhra Pradesh, India.";
		
		try {
			FileWriter output = new FileWriter("Data1.txt");
			output.write(data);
			System.out.println("Data is writen Successfully.");
			output.close();
		} 
		catch (IOException e)
		{
			System.out.println("File Write Error...");
		
			
		}
		
	}

}
