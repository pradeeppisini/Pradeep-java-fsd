package SleepWait;
import java.io.File;
import java.io.IOException;
public class CreateFileDemo {
	public static void main(String args[])
	{
		//File myFile = new File("data1.txt");
		File myFile = new File("D:\\javademo\\data1.txt");
		
		try {
			if (myFile.createNewFile()) {
				System.out.println("File created successfully.");
				
			}
			else
			{
				System.out.println("File creation error.");
			}
		} catch (IOException e) {
			System.out.println("File error...");
		}
		
	}

}
