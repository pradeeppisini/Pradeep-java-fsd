/**
 * 
 */
/**
 * 
 */
module ClassObject {
}