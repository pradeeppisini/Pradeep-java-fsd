package ClassObject;
//Define the shape class
abstract class shape
{
	abstract void draw();
}
//subclass Circle

class Circle extends shape{
	void draw() {
		System.out.println("Drawing Circle");
	}
}

//Subclass Rectangle
class Rectangle extends shape{
	void draw() {
		System.out.println("Drawing Rectangle");
	}
}

public class Polymorphism {
	public static void main(String args[])
	{
		//create objects of the subclasses
		shape shape1 = new Circle();
		shape shape2 = new Rectangle();
		
		//call the draw method
		shape1.draw();
		shape2.draw();
		
	}
	
	

}
