package ClassObject;
//Define the student class
class Student {
	String name;
	int rollNo;
	
	
	//Constructor
	Student(String name, int rollNo){
		this.name = name;
		this.rollNo = rollNo;
	}
	
	//Method to display the student details
	
	void display() {
		System.out.println("Name: "+ name);
		System.out.println("Roll No: "+ rollNo);
	}	
}

//Main class
public class ClassObject{
	public static void main(String args[]) {
		
		//create objects of the student class
		
		Student student1 = new Student("pradeep", 1);
		Student student2 = new Student("sam",2);
		
		
		//call the display method
		
		student1.display();
		student2.display();
		
}
	
}
	