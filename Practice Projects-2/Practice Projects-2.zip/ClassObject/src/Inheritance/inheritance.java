package Inheritance;

	// Parent class
	class Animal {
	    void eat() {
	        System.out.println("Eating...");
	    }
	}

	// Child class
	class Dog extends Animal {
	    void bark() {
	        System.out.println("Barking...");
	    }
	}

	// Test class to create objects and call methods
	public class inheritance {
	    public static void main(String args[]) {
	        Dog d = new Dog();
	        d.bark();
	        d.eat();
	    }
	}
