package DiamondProblem;

	interface A {
	    default void show() {
	        System.out.println("Default method in Interface A");
	    }
	}

	interface B {
	    default void show() {
	        System.out.println("Default method in Interface B");
	    }
	}

	class C implements A, B {
	    // Overriding 
	    public void show() {
	   
	        // method of A interface
	        A.super.show();

	        // method of B interface
	        B.super.show();
	    }
	}

public class DiamondTest {
	public static void main(String args[]) {
	   C c = new C();
	      c.show();
	    }
	}

