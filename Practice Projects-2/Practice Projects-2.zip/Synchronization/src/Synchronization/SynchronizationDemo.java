package Synchronization;

	class Counter {
	    int count;
	    // synchronized method to control simultaneous thread access
	    synchronized void increment() {
	        count++; //count = count + 1
	        System.out.println(count);
	    }
	}
	public class  SynchronizationDemo  {
	    public static void main(String[] args) throws Exception {
	        Counter c = new Counter();

	        // creating two threads
	        Thread t1 = new Thread(new Runnable() {
	            public void run() {
	                for (int i = 1; i <= 1000; i++) {
	                    c.increment();
	                }
	            }
	        });

	        Thread t2 = new Thread(new Runnable() {
	            public void run() {
	                for (int i = 1; i <= 1000; i++) {
	                    c.increment();
	                }
	            }
	        });

	        // starting two threads
	        t1.start();
	        t2.start();
	        
	        t1.join();
	        t2.join();

	        System.out.println("Count: " + c.count);
	    }
	}


