package TryCatch;


class CustomException extends Exception {
	CustomException(String s) {
		super(s);
		}
	}

public class CustomKeyword {
	static void validate(int age) throws CustomException {
		if (age < 18) {
			throw new CustomException("Not eligible for voting");
	        } 
		else
		{
			System.out.println("Eligible for voting");
	     }
	 }
public static void main(String args[]) {
	try {
		validate(13);
		} catch (Exception m) {
			System.out.println("Exception occured: " + m);
			}
	    }
	}

