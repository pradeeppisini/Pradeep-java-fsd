package TryCatch;

public class FinallyKeyword {
	
	    public static void main(String[] args) {
	        try {
	            System.out.println("Try block executed.");
	            // Simulating an exception
	            int result = 10 / 0;
	        } catch (ArithmeticException e) {
	            System.out.println("Exception caught: " + e.getMessage());
	        } finally {
	            System.out.println("Finally block executed.");
	        }
	    }
	}

