package TryCatch;
import java.io.IOException;
public class ThrowsKeyword {


	    void method() throws IOException {
	        throw new IOException("device error");
	    }

	    public static void main(String args[]) {
	        try {
	            new ThrowsKeyword().method();
	        } catch (Exception e) {
	            System.out.println("exception handled");
	        }
	    }
	}
